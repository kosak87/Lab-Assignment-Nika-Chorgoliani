import hashlib
import json
import sys
import os

HASH_FILE = "hashes.json"

def compute_hashes(filename):
    hashes = {
        "sha256": hashlib.sha256(),
        "sha1": hashlib.sha1(),
        "md5": hashlib.md5()
    }
    with open(filename, "rb") as f:
        data = f.read()
        for h in hashes.values():
            h.update(data)
    return {name: h.hexdigest() for name, h in hashes.items()}

def save_hashes(filename, hash_dict):
    with open(HASH_FILE, "w") as f:
        json.dump({filename: hash_dict}, f, indent=4)
    print("[+] Hashes saved to hashes.json")

def load_hashes():
    if not os.path.exists(HASH_FILE):
        return None
    with open(HASH_FILE, "r") as f:
        return json.load(f)

def check_integrity(filename, new_hashes):
    saved = load_hashes()
    if saved is None:
        print("[!] hashes.json not found.")
        return

    old_hashes = saved.get(filename)
    if not old_hashes:
        print("[!] No saved hashes for this file.")
        return

    print("\n--- Integrity Check ---")
    tampered = False

    for algo in ["sha256", "sha1", "md5"]:
        if old_hashes[algo] == new_hashes[algo]:
            print(f"{algo.upper()}: OK")
        else:
            print(f"{algo.upper()}: FAIL (changed!)")
            tampered = True

    if tampered:
        print("\n[!] WARNING: FILE TAMPERED!")
    else:
        print("\n[✓] Integrity Check Passed.")

def main():
    if len(sys.argv) < 2:
        print("Usage: python hash_util.py <filename>")
        return

    filename = sys.argv[1]
    hashes = compute_hashes(filename)

    if not os.path.exists(HASH_FILE):
        save_hashes(filename, hashes)
    else:
        check_integrity(filename, hashes)

if __name__ == "__main__":
    main()
